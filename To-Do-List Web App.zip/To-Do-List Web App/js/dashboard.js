(()=>{
  const $=id=>document.getElementById(id),E=Store.esc;
  function render(){
    const T=Store.all(),done=T.filter(t=>t.done),open=T.filter(t=>!t.done),over=open.filter(Store.overdue);
    const pct=T.length?Math.round(done.length/T.length*100):0;
    const stats=[["Total tasks",T.length,"pri"],["Completed",done.length,""],["In progress",open.length,""],["Overdue",over.length,over.length?"hot":""]];
    $("stats").innerHTML=stats.map(s=>`<div class="card stat ${s[2]}"><div class="n">${s[1]}</div><div class="l">${s[0]}</div></div>`).join("");
    $("ring").style.strokeDashoffset=326.7*(1-pct/100);$("pct").textContent=pct+"%";
    $("ringtxt").textContent=T.length?`${done.length} of ${T.length} tasks finished. ${open.length?open.length+" to go.":"Everything is done."}`:"Add a task to start tracking progress.";
    const days=[...Array(7)].map((_,i)=>{const d=new Date(Date.now()-(6-i)*864e5);return{k:Store.iso(+d),l:d.toLocaleDateString(undefined,{weekday:"short"})}});
    const c=days.map(d=>done.filter(t=>Store.iso(t.completedAt)===d.k).length),m=Math.max(...c,1);
    $("week").innerHTML=days.map((d,i)=>`<div class="bar">${c[i]||""}<i class="${c[i]?"":"z"}" style="height:${c[i]/m*100}%"></i>${d.l}</div>`).join("");
    $("prio").innerHTML=["high","medium","low"].map(p=>{const n=open.filter(t=>t.priority===p).length;return`<div class="row"><div><span>${p[0].toUpperCase()+p.slice(1)}</span><b>${n}</b></div><div class="track"><i style="width:${open.length?n/open.length*100:0}%"></i></div></div>`}).join("");
    const li=t=>`<li><span class="t">${E(t.text)}</span><span class="d ${Store.overdue(t)?"over":""}">${t.due?(Store.overdue(t)?"Overdue · ":"")+Store.fmt(t.due):t.category}</span></li>`;
    const up=open.filter(t=>t.due).sort((a,b)=>a.due.localeCompare(b.due)).slice(0,5);
    $("up").innerHTML=up.length?up.map(li).join(""):'<li class="empty">No deadlines set. Add a due date to see it here.</li>';
    const rc=T.slice().sort((a,b)=>b.created-a.created).slice(0,5);
    $("recent").innerHTML=rc.length?rc.map(t=>`<li><span class="t">${E(t.text)}</span><span class="d">${t.done?"Done":"Open"}</span></li>`).join(""):'<li class="empty">Nothing yet.</li>';
    $("side-stat").innerHTML=`<b>${open.length} open</b>${done.length} completed`;
  }
  const h=new Date().getHours();
  $("hello").textContent=h<12?"Good morning":h<18?"Good afternoon":"Good evening";
  $("date").textContent=new Date().toLocaleDateString(undefined,{weekday:"long",month:"long",day:"numeric"});
  $("qa").addEventListener("submit",e=>{e.preventDefault();const i=$("qt"),v=i.value.trim();if(!v)return;Store.add({text:v});i.value="";render()});
  render();
})();
