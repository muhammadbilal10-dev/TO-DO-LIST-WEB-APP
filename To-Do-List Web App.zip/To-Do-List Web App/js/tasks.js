(()=>{
  const $=id=>document.getElementById(id),L=$("list"),E=Store.esc;
  const PR={high:3,medium:2,low:1},CATS=["General","Work","Personal","Study","Health"];
  let f="all",q="",sort="new",edit=null;
  const opts=(a,c)=>a.map(v=>`<option value="${v}" ${v===c?"selected":""}>${v[0].toUpperCase()+v.slice(1)}</option>`).join("");
  function vis(){
    let a=Store.all().filter(t=>f==="all"||(f==="open"?!t.done:t.done));
    if(q)a=a.filter(t=>(t.text+" "+t.category).toLowerCase().includes(q));
    const s={new:(x,y)=>y.created-x.created,due:(x,y)=>(x.due||"9").localeCompare(y.due||"9"),pri:(x,y)=>PR[y.priority]-PR[x.priority]};
    return a.sort(s[sort]);
  }
  function row(t){
    if(edit===t.id)return`<li class="task" data-id="${t.id}"><form class="erow" data-act="save"><input type="text" name="text" value="${E(t.text)}" maxlength="200" required aria-label="Task text"><select name="priority" aria-label="Priority">${opts(["low","medium","high"],t.priority)}</select><input type="date" name="due" value="${t.due}" aria-label="Due date"><button class="btn">Save</button><button type="button" class="ghost" data-act="cancel">Cancel</button></form></li>`;
    const o=Store.overdue(t);
    return`<li class="task ${t.done?"done":""}" data-id="${t.id}"><input type="checkbox" data-act="toggle" ${t.done?"checked":""} aria-label="Mark as done"><div class="tmain"><span class="ttext" data-act="edit" title="Double-click to edit">${E(t.text)}</span><div class="meta"><span class="b ${t.priority}">${t.priority}</span><span class="b">${E(t.category)}</span>${t.due?`<span class="b ${o?"over":""}">${o?"Overdue · ":"Due "}${Store.fmt(t.due)}</span>`:""}</div></div><div class="acts"><button data-act="edit">Edit</button><button class="danger" data-act="del">Delete</button></div></li>`;
  }
  function render(){
    const all=Store.all(),items=vis(),d=all.filter(t=>t.done).length;
    L.innerHTML=items.map(row).join("");
    $("count").textContent=all.length?`${all.length-d} open, ${d} completed`:"No tasks yet";
    const e=$("empty");e.hidden=!!items.length;
    e.textContent=!all.length?"Your list is empty. Add your first task above.":q?"No tasks match your search.":f==="done"?"No completed tasks yet.":"All caught up. No open tasks.";
    $("clear").hidden=!d;
    $("side-stat").innerHTML=`<b>${all.length-d} open</b>${d} completed`;
    if(edit){const i=L.querySelector("[name=text]");i&&i.focus()}
  }
  $("cat").innerHTML=opts(CATS,"General");
  $("add").addEventListener("submit",e=>{e.preventDefault();const v=$("nt").value.trim();if(!v)return;
    Store.add({text:v,priority:$("pri").value,category:$("cat").value,due:$("due").value});$("nt").value="";$("due").value="";$("nt").focus();render()});
  L.addEventListener("click",e=>{const a=e.target.closest("[data-act]"),li=e.target.closest("li");if(!a||!li)return;const id=li.dataset.id,x=a.dataset.act;
    if(x==="toggle")Store.toggle(id);else if(x==="del")Store.remove(id);else if(x==="edit"&&e.target.tagName==="BUTTON")edit=id;else if(x==="cancel")edit=null;else return;render()});
  L.addEventListener("dblclick",e=>{const li=e.target.closest("li");if(li&&e.target.classList.contains("ttext")){edit=li.dataset.id;render()}});
  L.addEventListener("submit",e=>{e.preventDefault();const fd=new FormData(e.target),v=fd.get("text").trim();
    if(v)Store.update(e.target.closest("li").dataset.id,{text:v,priority:fd.get("priority"),due:fd.get("due")});edit=null;render()});
  L.addEventListener("keydown",e=>{if(e.key==="Escape"&&edit){edit=null;render()}});
  $("tabs").addEventListener("click",e=>{const b=e.target.closest("button");if(!b)return;f=b.dataset.f;[...$("tabs").children].forEach(x=>x.classList.toggle("on",x===b));render()});
  $("q").addEventListener("input",e=>{q=e.target.value.trim().toLowerCase();render()});
  $("sort").addEventListener("change",e=>{sort=e.target.value;render()});
  $("clear").addEventListener("click",()=>{Store.clearDone();render()});
  render();
  if(location.hash==="#new")$("nt").focus();
})();
