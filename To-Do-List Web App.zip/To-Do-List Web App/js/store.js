const Store=(()=>{
  const KEY="todo-app.tasks.v1";
  let tasks=[];
  try{const d=JSON.parse(localStorage.getItem(KEY));if(Array.isArray(d))tasks=d}catch{}
  tasks=tasks.map(t=>({priority:"medium",category:"General",due:"",created:Date.now(),completedAt:null,...t,completedAt:t.done?(t.completedAt||Date.now()):null}));
  const save=()=>{try{localStorage.setItem(KEY,JSON.stringify(tasks))}catch{}};
  const iso=ms=>new Date(ms-new Date(ms).getTimezoneOffset()*6e4).toISOString().slice(0,10);
  const find=id=>tasks.find(t=>t.id===id);
  return{
    all:()=>tasks.slice(),
    iso,today:()=>iso(Date.now()),
    overdue:t=>!t.done&&!!t.due&&t.due<iso(Date.now()),
    fmt:d=>new Date(d+"T00:00").toLocaleDateString(undefined,{month:"short",day:"numeric"}),
    esc:s=>String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c])),
    add(o){tasks.unshift({id:Date.now().toString(36)+Math.random().toString(36).slice(2,7),done:false,created:Date.now(),completedAt:null,priority:"medium",category:"General",due:"",...o});save()},
    update(id,p){const t=find(id);if(t){Object.assign(t,p);save()}},
    toggle(id){const t=find(id);if(t){t.done=!t.done;t.completedAt=t.done?Date.now():null;save()}},
    remove(id){tasks=tasks.filter(t=>t.id!==id);save()},
    clearDone(){tasks=tasks.filter(t=>!t.done);save()}
  };
})();
